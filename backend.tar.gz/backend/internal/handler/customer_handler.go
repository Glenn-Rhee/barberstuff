package handler

import (
	"barberstuff_backend/internal/dto"
	"barberstuff_backend/internal/entity"
	"barberstuff_backend/internal/helper"
	"barberstuff_backend/internal/lib"
	"barberstuff_backend/internal/service"
	"net/http"

	"github.com/gin-gonic/gin"
)

type CustomerHandler struct {
	service service.CustomerService
}

func NewCustomerHandler(service service.CustomerService) *CustomerHandler {
	return &CustomerHandler{service: service}
}

func (h *CustomerHandler) OauthRegister(ctx *gin.Context) {
	var dataNewCustomer dto.OauthCustomerRequest

	if err := ctx.ShouldBindJSON(&dataNewCustomer); err != nil {
		helper.NewErrorResponse(ctx, dto.ResponseApi[any]{
			Message:    helper.FormatValidationError(err)[0],
			StatusCode: http.StatusBadRequest,
		})
		return
	}

	if !helper.ValidatePhoneNumber(dataNewCustomer.PhoneNumber) {
		helper.NewErrorResponse(ctx, dto.ResponseApi[any]{
			Message:    "No telepon tidak valid, gunakan format +62xxxx atau 08xxxx",
			StatusCode: http.StatusBadRequest,
		})
		return
	}

	result, err := h.service.OauthRegister(dataNewCustomer, ctx.Request.Context())

	if err != nil {
		helper.NewErrorResponse(ctx, dto.ResponseApi[any]{
			Message:    err.Error(),
			StatusCode: http.StatusBadRequest,
		})
		return
	}

	helper.NewSuccessResponse(ctx, dto.ResponseApi[dto.AuthenticationResponse]{
		Message:    "Berhasil registrasi dengan google!",
		Data:       result,
		StatusCode: http.StatusOK,
	})
}

func (h *CustomerHandler) CredentialRegister(ctx *gin.Context) {
	var dataNewCustomer dto.CredentialCustomerRequest
	if err := ctx.ShouldBindJSON(&dataNewCustomer); err != nil {
		helper.NewErrorResponse(ctx, dto.ResponseApi[any]{
			Message:    helper.FormatValidationError(err)[0],
			StatusCode: http.StatusBadRequest,
		})
		return
	}

	if !helper.ValidatePhoneNumber(dataNewCustomer.PhoneNumber) {
		helper.NewErrorResponse(ctx, dto.ResponseApi[any]{
			Message:    "No telepon tidak valid, gunakan format +62xxxx atau 08xxxx",
			StatusCode: http.StatusBadRequest,
		})
		return
	}

	if !helper.ValidateMinAge(dataNewCustomer.DateOfBirth) {
		helper.NewErrorResponse(ctx, dto.ResponseApi[any]{
			Message:    "Minimal usia untuk mendaftar adalah 6 bulan!",
			StatusCode: http.StatusBadRequest,
		})
		return
	}

	result, err := h.service.CredentialRegister(dataNewCustomer, ctx.Request.Context())
	if err != nil {
		helper.NewErrorResponse(ctx, dto.ResponseApi[any]{
			Message:    err.Error(),
			StatusCode: http.StatusNotAcceptable,
		})
		return
	}

	helper.NewSuccessResponse(ctx, dto.ResponseApi[dto.CredentialCustomerResponse]{
		Message:    "OTP telah dikirim ke email Anda. Silakan periksa kotak masuk atau spam.",
		Data:       *result,
		StatusCode: http.StatusOK,
	})
}

func (h *CustomerHandler) VerifyCredential(ctx *gin.Context) {
	var dataOtpCustomer dto.VerifyCredentialRequest

	if err := ctx.ShouldBindJSON(&dataOtpCustomer); err != nil {
		helper.NewErrorResponse(ctx, dto.ResponseApi[any]{
			Message:    helper.FormatValidationError(err)[0],
			StatusCode: http.StatusBadRequest,
		})
		return
	}

	if !helper.ValidateOTP(dataOtpCustomer.OTP) {
		helper.NewErrorResponse(ctx, dto.ResponseApi[any]{
			Message:    "Hanya masukkan OTP berupa angka diantara 0-9",
			StatusCode: http.StatusBadRequest,
		})
		return
	}

	result, err := h.service.VerifyOTP(ctx.Request.Context(), dataOtpCustomer)
	if err != nil {
		helper.NewErrorResponse(ctx, dto.ResponseApi[any]{
			Message:    err.Error(),
			StatusCode: http.StatusNotAcceptable,
		})
		return
	}

	helper.NewSuccessResponse(ctx, dto.ResponseApi[dto.VerifyOTPResponse]{
		Message:    "Berhasil verifikasi!",
		Data:       result,
		StatusCode: http.StatusOK,
	})
}

func (h *CustomerHandler) ForgotPassword(ctx *gin.Context) {
	var dataResetPassword dto.ForgotPasswordRequest

	if err := ctx.ShouldBindJSON(&dataResetPassword); err != nil {
		helper.NewErrorResponse(ctx, dto.ResponseApi[any]{
			Message:    helper.FormatValidationError(err)[0],
			StatusCode: http.StatusBadRequest,
		})
		return
	}

	result, err := h.service.ForgotPassword(ctx.Request.Context(), dataResetPassword)
	if err != nil {
		helper.NewErrorResponse(ctx, dto.ResponseApi[any]{
			Message:    err.Error(),
			StatusCode: http.StatusNotAcceptable,
		})
		return
	}

	helper.NewSuccessResponse(ctx, dto.ResponseApi[dto.ForgotPassswordResponse]{
		Message:    "Berhasil kirim otp",
		Data:       result,
		StatusCode: http.StatusOK,
	})
}

func (h *CustomerHandler) GetProfile(ctx *gin.Context) {
	claims, exist := ctx.Get("claims")
	if !exist {
		helper.NewErrorResponse(ctx, dto.ResponseApi[any]{
			Message:    "Anda tidak memiliki akses!",
			StatusCode: http.StatusUnauthorized,
		})
		return
	}

	claimsResult, ok := claims.(*lib.CustomClaims)
	if !ok {
		helper.NewErrorResponse(ctx, dto.ResponseApi[any]{
			Message:    "Gagal membaca data!",
			StatusCode: http.StatusUnauthorized,
		})
		return
	}

	if claimsResult.Role != entity.RoleCustomer {
		helper.NewErrorResponse(ctx, dto.ResponseApi[any]{
			Message:    "Anda tidak memiliki akses!",
			StatusCode: http.StatusUnauthorized,
		})
		return
	}

	result, err := h.service.GetProfile(claimsResult)
	if err != nil {
		helper.NewErrorResponse(ctx, dto.ResponseApi[any]{
			Message:    err.Error(),
			StatusCode: http.StatusNotAcceptable,
		})
		return
	}

	helper.NewSuccessResponse(ctx, dto.ResponseApi[dto.ProfileCustomerResponse]{
		Message:    "Berhasil mengambil data!",
		Data:       result,
		StatusCode: http.StatusUnauthorized,
	})
}
